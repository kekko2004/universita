package com.libretto_universtia.controller;

import com.libretto_universtia.model.Esame;
import com.libretto_universtia.model.Studente;
import com.libretto_universtia.service.EsameService;
import com.libretto_universtia.service.StudenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class LibrettoController {

    @Autowired
    private EsameService esameService;

    @Autowired
    private StudenteService studenteService;

    @GetMapping("/")
    public String homepage(Model model){
        List<Studente> stud = studenteService.getAllStudenti();
        model.addAttribute("studenti", stud);
        return "homepage";
    }

    @GetMapping("/home/aggiungiStudenti")
    public String showAddStudenti(Model model){
        Studente studente = new Studente();
        model.addAttribute("studente", studente);
        return "addStudente";
    }

    @PostMapping("/home/aggiungiStudenti")
    public String addStudenti(@ModelAttribute Studente studente){
        studenteService.addStudente(studente);
        return "redirect:/";
    }

    @PostMapping("/home")
    public String home(@RequestParam String matricola, Model model) {
        List<Esame> esami = esameService.getEsamiByMatricola(matricola);
        model.addAttribute("esami", esami);
        model.addAttribute("matricola", matricola);
        return "home";
    }

    @GetMapping("/home/add/{matricola}")
    public String showAddForm(@PathVariable String matricola, Model model){
        Esame esame = new Esame(matricola);
        model.addAttribute("esame", esame);
        return "addEsame";
    }

    @PostMapping("/home/add")
    public String addEsame(@ModelAttribute Esame esame){
        esameService.addEsame(esame);
        return "redirect:/";
    }

    @GetMapping("/home/editStudente/{matricola}")
    public String showEditStudenteForm(@PathVariable String matricola, Model model) {
        Studente studente = studenteService.getStudenteByMatricola(matricola);
        model.addAttribute("studente", studente);
        return "editStudente";
    }

    @PostMapping("/home/editStudente")
    public String editStudente(@ModelAttribute Studente studente) {
        studenteService.aggiornaStudente(studente);
        return "redirect:/";
    }

    @GetMapping("/home/edit/{id}")
    public String showEditEsameForm(@PathVariable int id, Model model) {
        Esame esame = esameService.getEsameById(id);
        model.addAttribute("esame", esame);
        return "editEsame";
    }

    @PostMapping("/home/edit")
    public String editEsame(@ModelAttribute Esame esame) {
        esameService.aggiornaEsame(esame);
        return "redirect:/";
    }

    @GetMapping("home/remove/{id}")
    public String rimuoviEsame(@PathVariable int id) {
        esameService.eliminaEsame(id);
        return "redirect:/";
    }

    @GetMapping("home/deleteStudente/{matricola}")
    public String rimuoviEsame(@PathVariable String matricola) {
        studenteService.eliminaStudente(matricola);
        return "redirect:/";
    }

}
