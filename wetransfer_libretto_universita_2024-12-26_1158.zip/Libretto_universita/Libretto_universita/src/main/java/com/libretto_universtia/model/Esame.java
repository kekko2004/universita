package com.libretto_universtia.model;

public class Esame {
    private static int idCounter = 0;
    private static int cont=0;
    private int id;

    private String matricola;

    private int voto;
    private String materia;
    private String data;

    public Esame() {
        this.id = idCounter;
    }

    public Esame(int i) {
        this.id = idCounter;

            idCounter++;
    }

    public Esame(String matricola) {
        this.id = idCounter;
        this.matricola = matricola;
        idCounter++;
    }

    public Esame(int voto, String materia, String data, String matricola) {
        this.id = idCounter;
        if((cont++)%2==0)
            idCounter++;
        this.voto = voto;
        this.materia = materia;
        this.data = data;
        this.matricola = matricola;
    }

    public String getMatricola() {
        return matricola;
    }

    public void setMatricola(String matricola) {
        this.matricola = matricola;
    }

    public static int getIdCounter() {
        return idCounter;
    }

    public static void setIdCounter(int idCounter) {
        Esame.idCounter = idCounter;
    }

    public static int getCont() {
        return cont;
    }

    public static void setCont(int cont) {
        Esame.cont = cont;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVoto() {
        return voto;
    }

    public void setVoto(int voto) {
        this.voto = voto;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
