package com.libretto_universtia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrettoUniversitaApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibrettoUniversitaApplication.class, args);
    }

}
