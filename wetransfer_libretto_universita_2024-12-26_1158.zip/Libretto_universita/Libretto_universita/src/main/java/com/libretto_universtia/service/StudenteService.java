package com.libretto_universtia.service;

import com.libretto_universtia.model.Esame;
import com.libretto_universtia.model.Studente;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class StudenteService {
    List<Studente> studenti = new ArrayList<>();

    public List<Studente> getAllStudenti(){
        return studenti;
    }

    public void addStudente(Studente studente){
        studenti.add(studente);
    }

    public Studente getStudenteByMatricola(String matricola){
        for(Studente s:studenti){
            if(s.getMatricola().equalsIgnoreCase(matricola)){
                return s;
            }
        }
        return null;
    }

    public void eliminaStudente(String matricola) {
        studenti.removeIf(studente -> studente.getMatricola().equalsIgnoreCase(matricola));
    }

    public void aggiornaStudente(Studente studente) {
        int index = this.getAllStudenti().indexOf(this.getStudenteByMatricola(studente.getMatricola()));
        if(index != -1) {
            this.getAllStudenti().set(index, studente);
        }
    }

}
