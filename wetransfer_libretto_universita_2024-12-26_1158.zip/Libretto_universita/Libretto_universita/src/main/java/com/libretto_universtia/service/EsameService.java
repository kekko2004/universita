package com.libretto_universtia.service;

import com.libretto_universtia.model.Esame;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EsameService {
    private List<Esame> esami = new ArrayList<>();

    public List<Esame> getAllEsami() {
        return esami;
    }

    public List<Esame> getEsamiByMatricola(String matricola){
        List<Esame> temp = new ArrayList<>();

        for(Esame e: esami){
            if(e.getMatricola().equalsIgnoreCase(matricola)){
                temp.add(e);
            }
        }
        return temp;
    }

    public Esame getEsameById(int id){
        for(Esame e:esami){
            if(e.getId() == id){
                return e;
            }
        }
        return null;
    }

    public void addEsame(Esame esame){
        esami.add(esame);
    }

    public void eliminaEsame(int id) {
        esami.removeIf(esame -> esame.getId() == id);
    }

    public void aggiornaEsame(Esame esame) {
        int index = this.getAllEsami().indexOf(this.getEsameById(esame.getId()));
        if(index != -1) {
            this.getAllEsami().set(index, esame);
        }
    }
}
