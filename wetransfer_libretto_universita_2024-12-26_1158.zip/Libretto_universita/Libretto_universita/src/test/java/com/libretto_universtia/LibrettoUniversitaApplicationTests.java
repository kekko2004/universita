package com.libretto_universtia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrettoUniversitaApplicationTests {

    @Test
    void contextLoads() {
    }

}
